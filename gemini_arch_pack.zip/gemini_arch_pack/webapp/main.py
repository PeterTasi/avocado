from __future__ import annotations

import hashlib
import json
import sys
from functools import wraps
from pathlib import Path
from typing import Any, Callable, TypeVar

from cachetools import TTLCache
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

# ruff: noqa: E402
from adaptlearn.config import Settings
from adaptlearn.pipeline import AdaptLearnService

STATIC_DIR = Path(__file__).resolve().parent / "static"

app = FastAPI(title="AdaptLearn Web API", version="0.1.0")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

_settings = Settings()
_active_key = _settings.gemini_api_key
_service = AdaptLearnService(_settings, api_key=_active_key)

_cache: TTLCache[str, Any] = TTLCache(maxsize=128, ttl=30)
_cache_large: TTLCache[str, Any] = TTLCache(maxsize=32, ttl=60)

F = TypeVar("F", bound=Callable[..., Any])


def _cache_key(*args, **kwargs) -> str:
    key_data = json.dumps({"args": args, "kwargs": kwargs}, sort_keys=True, default=str)
    return hashlib.md5(key_data.encode()).hexdigest()


def cached(cache: TTLCache[str, Any] = None):
    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args, **kwargs):
            c = cache or _cache
            key = f"{func.__name__}:{_cache_key(*args, **kwargs)}"
            if key in c:
                return c[key]
            result = func(*args, **kwargs)
            c[key] = result
            return result
        return wrapper  # type: ignore
    return decorator


def invalidate_cache(*patterns: str) -> None:
    keys_to_delete = [
        k for k in list(_cache.keys()) + list(_cache_large.keys())
        if any(p in k for p in patterns)
    ]
    for k in keys_to_delete:
        _cache.pop(k, None)
        _cache_large.pop(k, None)


class ApiKeyRequest(BaseModel):
    api_key: str = ""


class GenerateRequest(BaseModel):
    question_count: int = Field(default=9, ge=1, le=30)


class GradeRequest(BaseModel):
    answer: str = Field(min_length=1)


def _get_service(api_key_override: str | None = None) -> AdaptLearnService:
    global _active_key
    global _service

    if api_key_override is None:
        return _service

    normalized = api_key_override.strip()
    if normalized != _active_key:
        _service = AdaptLearnService(_settings, api_key=normalized)
        _active_key = normalized
    return _service


def _serialize_question(question) -> dict[str, Any]:
    return {
        "id": question.id,
        "concept_id": question.concept_id,
        "concept_name": question.concept_name,
        "difficulty": question.difficulty,
        "question_text": question.question_text,
        "answer_text": question.answer_text,
        "rationale": question.rationale,
    }


def _serialize_review_item(item) -> dict[str, Any]:
    return {
        "concept_id": item.concept_id,
        "concept_name": item.concept_name,
        "priority": item.priority,
        "next_review_at": item.next_review_at.isoformat(timespec="seconds"),
        "suggested_slot": item.suggested_slot,
        "reason": item.reason,
    }


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
@cached(_cache)
def health() -> dict[str, Any]:
    service = _get_service()
    return {
        "status": "ok",
        "llm_enabled": service.llm_enabled,
        "metrics": service.get_metrics(),
    }


@app.post("/api/config/api-key")
def configure_api_key(payload: ApiKeyRequest) -> dict[str, Any]:
    service = _get_service(payload.api_key)
    invalidate_cache("health", "concept", "mastery", "tonight", "graph", "review", "questions")
    return {"llm_enabled": service.llm_enabled}


@app.post("/api/material/ingest")
async def ingest_material(
    file: UploadFile = File(...),
    course_name: str = Form("General Course"),
    template_mode: str = Form("generic"),
    api_key: str | None = Form(default=None),
) -> dict[str, Any]:
    if not file.filename:
        raise HTTPException(status_code=400, detail="缺少檔名，請重新上傳。")

    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="上傳檔案是空的，請確認內容。")

    service = _get_service(api_key_override=api_key)
    try:
        result = service.ingest_material(
            file_name=file.filename,
            file_bytes=file_bytes,
            course_name=course_name.strip() or "Course",
            template_mode=template_mode,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"教材處理失敗：{exc}") from exc

    invalidate_cache("concept", "mastery", "tonight", "graph", "health", "review")
    return {"ok": True, **result}


@app.get("/api/concepts")
@cached(_cache_large)
def list_concepts() -> dict[str, Any]:
    concepts = _get_service().list_concepts()
    return {
        "items": [
            {
                "id": concept.id,
                "name": concept.name,
                "chapter": concept.chapter,
                "description": concept.description,
                "prerequisites": concept.prerequisites,
            }
            for concept in concepts
        ]
    }


@app.get("/api/graph")
@cached(_cache)
def get_graph() -> dict[str, str]:
    return {"dot": _get_service().get_graphviz()}


@app.get("/api/mastery/concepts")
@cached(_cache)
def concept_mastery() -> dict[str, Any]:
    return {"items": _get_service().get_concept_mastery()}


@app.get("/api/mastery/chapters")
@cached(_cache)
def chapter_mastery() -> dict[str, Any]:
    return {"items": _get_service().get_chapter_mastery()}


@app.post("/api/diagnostics/generate")
def generate_diagnostics(payload: GenerateRequest) -> dict[str, Any]:
    questions = _get_service().generate_diagnostics(question_count=payload.question_count)
    invalidate_cache("questions")
    return {"items": [_serialize_question(question) for question in questions]}


@app.get("/api/questions")
@cached(_cache)
def list_questions(limit: int = 100) -> dict[str, Any]:
    questions = _get_service().list_questions(limit=max(1, min(limit, 500)))
    return {"items": [_serialize_question(question) for question in questions]}


@app.post("/api/questions/{question_id}/grade")
def grade_question(question_id: str, payload: GradeRequest) -> dict[str, Any]:
    answer = payload.answer.strip()
    if not answer:
        raise HTTPException(status_code=400, detail="作答內容不可空白。")

    try:
        result = _get_service().grade_question(question_id=question_id, user_answer=answer)
        invalidate_cache("mastery", "tonight", "health", "review")
        return result
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/review/recalculate")
def recalculate_review_plan() -> dict[str, Any]:
    items = _get_service().build_and_save_review_plan()
    invalidate_cache("tonight", "review")
    return {"items": [_serialize_review_item(item) for item in items]}


@app.get("/api/review")
@cached(_cache)
def list_review_plan() -> dict[str, Any]:
    items = _get_service().list_review_plan()
    return {"items": [_serialize_review_item(item) for item in items]}


@app.get("/api/tonight")
@cached(_cache)
def tonight_dashboard(top_n: int = 5) -> dict[str, Any]:
    top_n = max(1, min(top_n, 20))
    return _get_service().get_tonight_study_dashboard(top_n=top_n)
